#ifndef __MOD_SHT3X_H
#define __MOD_SHT3X_H

#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif

#include "Wire.h"

// SHT30 status
#define SHT30_READ_OK 0
#define SHT30_I2C_WRITE_ERROR 1
#define SHT30_I2C_READ_ERROR 2
#define SHT30_CRC_ERROR 3

class SHT30{
	public:
		SHT30(uint8_t address=0x45);
		byte read_single_shot(void);
		byte read_status_register(void);
		int check_crc(uint8_t data0, uint8_t data1, uint8_t crc_received);
		uint16_t	status_reg;
		float cTemp=0;
		float fTemp=0;
		float humidity=0;

	private:
		uint8_t _address;
};

#endif
