/*
 * Edited by Bruno Casu - March 2024
*/

#include "sht30.h"

SHT30::SHT30(uint8_t address)
{
	Wire.begin();
	_address=address;
}

int SHT30::check_crc(uint8_t data0, uint8_t data1, uint8_t crc_received) {
    const uint8_t polynomial = 0b100110001; // CRC-8 polynomial: x^8 + x^5 + x^4 + 1
    uint8_t crc = 0xff; // Initial CRC value

    // Combine two data bytes into a 16-bit value
    uint16_t buff = (data0 << 8) | data1;

    for (int i = 15; i >= 0; --i) {
        uint16_t bit = (buff >> i) & 0x01;
        uint16_t crc_bit = (crc >> 7) & 0x01;
        crc = crc << 1;
        if (bit ^ crc_bit) {
            crc = crc ^ polynomial;
        }
    }
    if (crc == crc_received){
      return 1; // CRC OK
    }
    else {
      return 0; // CRC check failed
    }
}

byte SHT30::read_single_shot()
{
	unsigned int buff[6];

	// Start I2C Transmission
	Wire.beginTransmission(_address);
	// Send measurement command
	Wire.write(0x2C);
	Wire.write(0x06);
	// Stop I2C transmission
	if (Wire.endTransmission()!=0)
		return SHT30_I2C_WRITE_ERROR;

	delay(1);

	// Request 6 bytes of data
	Wire.requestFrom(_address, 6);

	// Read 6 bytes of data
	// cTemp msb, cTemp lsb, cTemp crc, humidity msb, humidity lsb, humidity crc
	for (int i=0;i<6;i++) {
		buff[i]=Wire.read();
	};

	delay(1);

	if (Wire.available()!=0)
		return SHT30_I2C_READ_ERROR;

  // Check CRC for temperature data
  if (!check_crc(buff[0], buff[1], buff[2])) {
    // Serial.print("\n-->SHT30_CRC_ERROR temp");
    return SHT30_CRC_ERROR;
  }
  // Check CRC for humidity data
  if (!check_crc(buff[3], buff[4], buff[5])) {
    // Serial.print("\n-->SHT30_CRC_ERROR hum");
    return SHT30_CRC_ERROR;
  }

	// Convert the data
	cTemp = ((((buff[0] * 256.0) + buff[1]) * 175) / 65535.0) - 45;
	fTemp = (cTemp * 1.8) + 32;
	humidity = ((((buff[3] * 256.0) + buff[4]) * 100) / 65535.0);

	return SHT30_READ_OK;
}

byte SHT30::read_status_register()
{
	unsigned int buff[3];

	// Start I2C Transmission
	Wire.beginTransmission(_address);
	// read status register command
	Wire.write(0xF3);
	Wire.write(0x2D);
	// Stop I2C transmission
	if (Wire.endTransmission()!=0)
		return SHT30_I2C_WRITE_ERROR;

	delay(1);

	// Request 3 bytes of data
	Wire.requestFrom(_address, 3);

	// Read 3 bytes of data
	// cTemp msb, cTemp lsb, cTemp crc, humidity msb, humidity lsb, humidity crc
	for (int i=0;i<3;i++) {
		buff[i]=Wire.read();
	};

	delay(1);

	if (Wire.available()!=0)
		return SHT30_I2C_READ_ERROR;

  // Check CRC for temperature data
  if (!check_crc(buff[0], buff[1], buff[2])) {
    // Serial.print("\n-->SHT30_CRC_ERROR temp");
    return SHT30_CRC_ERROR;
  }

	status_reg = (buff[0] << 8) | buff[1];

	return SHT30_READ_OK;
}
