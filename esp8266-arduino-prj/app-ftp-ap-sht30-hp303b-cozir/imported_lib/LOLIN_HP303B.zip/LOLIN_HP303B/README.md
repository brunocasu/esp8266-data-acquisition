# Arduino library for the HP303B
### Installation
- Clone this repository  or download&unzip [zip file](https://github.com/wemos/LOLIN_HP303B_Library/archive/master.zip) into Arduino/libraries

